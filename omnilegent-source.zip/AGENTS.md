<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Documents are parsed in the browser (pdfjs-dist v4; v5+ breaks in current browsers) into per-page images + text; the server sends page images to the AI so visuals are read visually. Why: charts/tables/scans need vision, and no storage is needed.
- Theme selection uses the root dark class with semantic CSS overrides and browser-local preference storage, applied after hydration to keep server rendering safe.
