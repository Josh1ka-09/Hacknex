// Browser-only document ingestion: renders every page to an image and pulls its text layer.
export type DocPage = { page: number; text: string; image: string; thumb: string };
export type Doc = { id: string; name: string; kind: "pdf" | "image"; pages: DocPage[] };

const MAX_SIDE = 1400;

function canvasToJpeg(canvas: HTMLCanvasElement, quality = 0.82) {
  return canvas.toDataURL("image/jpeg", quality);
}

function thumbFrom(canvas: HTMLCanvasElement) {
  const t = document.createElement("canvas");
  const s = 220 / canvas.width;
  t.width = 220;
  t.height = Math.round(canvas.height * s);
  t.getContext("2d")!.drawImage(canvas, 0, 0, t.width, t.height);
  return canvasToJpeg(t, 0.7);
}

export async function ingestFile(file: File, onProgress?: (done: number, total: number) => void): Promise<Doc> {
  const id = crypto.randomUUID();
  if (file.type.startsWith("image/")) {
    const url = URL.createObjectURL(file);
    const img = await new Promise<HTMLImageElement>((res, rej) => {
      const i = new Image();
      i.onload = () => res(i);
      i.onerror = rej;
      i.src = url;
    });
    const scale = Math.min(1, MAX_SIDE / Math.max(img.width, img.height));
    const c = document.createElement("canvas");
    c.width = Math.round(img.width * scale);
    c.height = Math.round(img.height * scale);
    const ctx = c.getContext("2d")!;
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, c.width, c.height);
    ctx.drawImage(img, 0, 0, c.width, c.height);
    URL.revokeObjectURL(url);
    onProgress?.(1, 1);
    return { id, name: file.name, kind: "image", pages: [{ page: 1, text: "", image: canvasToJpeg(c), thumb: thumbFrom(c) }] };
  }

  const pdfjs = await import("pdfjs-dist");
  const workerUrl = (await import("pdfjs-dist/build/pdf.worker.min.mjs?url")).default;
  pdfjs.GlobalWorkerOptions.workerSrc = workerUrl;
  const pdf = await pdfjs.getDocument({ data: await file.arrayBuffer() }).promise;
  const pages: DocPage[] = [];
  for (let n = 1; n <= pdf.numPages; n++) {
    const page = await pdf.getPage(n);
    const base = page.getViewport({ scale: 1 });
    const scale = MAX_SIDE / Math.max(base.width, base.height);
    const viewport = page.getViewport({ scale });
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(viewport.width);
    canvas.height = Math.round(viewport.height);
    const ctx = canvas.getContext("2d")!;
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    await page.render({ canvasContext: ctx, viewport }).promise;
    const tc = await page.getTextContent();
    let text = "";
    let lastY: number | null = null;
    for (const item of tc.items as Array<{ str?: string; transform?: number[] }>) {
      if (!item.str) continue;
      const y = item.transform?.[5] ?? 0;
      if (lastY !== null && Math.abs(y - lastY) > 2) text += "\n";
      else if (text && !text.endsWith(" ")) text += " ";
      text += item.str;
      lastY = y;
    }
    pages.push({ page: n, text, image: canvasToJpeg(canvas), thumb: thumbFrom(canvas) });
    onProgress?.(n, pdf.numPages);
  }
  return { id, name: file.name, kind: "pdf", pages };
}

const STOP = new Set("the a an of to in on for and or is are was were what which who how does do did with by from at as that this it be".split(" "));

/** Pick the pages most likely to hold the answer. Visual/scanned pages are always kept in contention. */
export function selectPages(docs: Doc[], question: string, limit = 18) {
  const terms = question.toLowerCase().match(/[a-z0-9%$.]+/g)?.filter((t) => t.length > 2 && !STOP.has(t)) ?? [];
  const all = docs.flatMap((d) => d.pages.map((p) => ({ doc: d, p })));
  if (all.length <= limit) return all;
  const visualWords = /chart|graph|figure|fig\.|plot|trend|table|diagram|image|photo|scan/;
  const wantsVisual = visualWords.test(question.toLowerCase());
  const scored = all.map(({ doc, p }) => {
    const t = p.text.toLowerCase();
    let s = 0;
    for (const term of terms) {
      const hits = t.split(term).length - 1;
      s += Math.min(hits, 5);
    }
    if (p.text.trim().length < 200) s += 3; // scanned or mostly-visual page — text layer can't judge it
    if (wantsVisual && visualWords.test(t)) s += 2;
    if (doc.name.toLowerCase().split(/[^a-z0-9]+/).some((w) => terms.includes(w))) s += 1;
    return { doc, p, s };
  });
  scored.sort((a, b) => b.s - a.s);
  return scored.slice(0, limit).sort((a, b) => (a.doc.id === b.doc.id ? a.p.page - b.p.page : 0));
}
