import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const input = z.object({
  question: z.string().min(1).max(2000),
  pages: z
    .array(
      z.object({
        document: z.string(),
        page: z.number(),
        text: z.string(),
        image: z.string().startsWith("data:image/"),
      }),
    )
    .min(1)
    .max(40),
});

export const askDocuments = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => input.parse(data))
  .handler(async ({ data }) => {
    const { answerQuestion } = await import("./qa.server");
    try {
      const answer = await answerQuestion(data.question, data.pages);
      return { ok: true as const, answer };
    } catch (e: unknown) {
      const err = e as { statusCode?: number; message?: string };
      const status = err.statusCode;
      const message =
        status === 402
          ? "AI credits are used up for this workspace. Add credits to keep asking questions."
          : status === 429
            ? "Too many requests right now — please wait a moment and try again."
            : err.message || "Something went wrong while analysing the documents.";
      console.error("askDocuments failed", status, err.message);
      return { ok: false as const, error: message };
    }
  });
