import { createOpenAI } from "@ai-sdk/openai";
import { streamText, Output, NoObjectGeneratedError, type ModelMessage } from "ai";
import { z } from "zod";

const LOVABLE_AIG_RUN_ID_HEADER = "X-Lovable-AIG-Run-ID";

function createRunIdFetch() {
  let runId: string | undefined;
  return async (input: RequestInfo | URL, init?: RequestInit) => {
    const headers = new Headers(init?.headers);
    if (runId && !headers.has(LOVABLE_AIG_RUN_ID_HEADER)) headers.set(LOVABLE_AIG_RUN_ID_HEADER, runId);
    const response = await fetch(input, { ...init, headers });
    runId ??= response.headers.get(LOVABLE_AIG_RUN_ID_HEADER)?.trim() || undefined;
    return response;
  };
}

export const answerSchema = z.object({
  answer: z.string(),
  confidence: z.enum(["high", "medium", "low"]),
  citations: z.array(
    z.object({
      ref: z.number(),
      document: z.string(),
      page: z.number(),
      section: z.string(),
      modality: z.enum(["text", "table", "chart", "image", "scanned"]),
      evidence: z.string(),
    }),
  ),
});

export type QAAnswer = z.infer<typeof answerSchema>;

export type QAPage = { document: string; page: number; text: string; image: string };

const INSTRUCTIONS = `You are a meticulous document analyst. You receive pages from one or more documents.
Each page arrives as a labelled block "[DOC: name | PAGE: n]" with its extracted text layer (may be empty for scanned pages) followed by a rendered image of the page.

Rules:
- The page IMAGE is the ground truth. Read tables, charts, graphs, diagrams, photos and scanned pages visually from the image — read axis labels, legends, bar heights, line trends and cell values from the picture, never only from the text layer.
- Combine evidence across text, tables and charts and across documents when the question requires it. Show any arithmetic briefly.
- Every factual claim in "answer" must carry an inline marker like [1], [2] that matches a citation "ref".
- Each citation: exact document name as given, page number, the section heading the evidence sits under (infer from nearby headings; for figures use the figure/table caption, e.g. "Table 3 – Revenue by region"; use "Untitled section" if none), modality of the evidence (text, table, chart, image, or scanned), and a short evidence note (a quote for text, or the specific values/cells/bars you read for visual content).
- If the pages do not contain the answer, say so plainly with confidence "low" and no invented citations.
- Write the answer in concise Markdown (short paragraphs or bullets). Keep it under 250 words.`;

export async function answerQuestion(question: string, pages: QAPage[]): Promise<QAAnswer> {
  const apiKey = process.env['LOVABLE_API_KEY'];
  if (!apiKey) throw new Error("AI is not configured for this app.");

  const provider = createOpenAI({
    baseURL: "https://ai.gateway.lovable.dev/v1",
    apiKey,
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    fetch: createRunIdFetch(),
  });

  const content: Array<{ type: "text"; text: string } | { type: "image"; image: URL }> = [];
  for (const p of pages) {
    content.push({
      type: "text",
      text: `[DOC: ${p.document} | PAGE: ${p.page}]\nText layer:\n${p.text.trim() ? p.text.slice(0, 6000) : "(no text layer — likely scanned or purely visual; read the image)"}`,
    });
    content.push({ type: "image", image: new URL(p.image) });
  }
  content.push({ type: "text", text: `Question: ${question}` });

  const messages: ModelMessage[] = [{ role: "user", content }];

  const result = streamText({
    model: provider.responses("openai/gpt-6-astra"),
    instructions: INSTRUCTIONS,
    messages,
    output: Output.object({ schema: answerSchema }),
    providerOptions: {
      openai: {
        forceReasoning: true,
        reasoningEffort: "medium",
        reasoningSummary: "auto",
        store: false,
        include: ["reasoning.encrypted_content"],
      },
    },
  });

  try {
    return await result.output;
  } catch (error) {
    if (NoObjectGeneratedError.isInstance(error) && error.text) {
      try {
        return answerSchema.parse(JSON.parse(error.text));
      } catch {
        /* fall through */
      }
    }
    throw error;
  }
}
