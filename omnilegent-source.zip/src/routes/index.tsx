import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { FileText, Table2, BarChart3, ImageIcon, ScanLine, Upload, X, ArrowUp, Loader2, BookOpen, Sun, Moon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { askDocuments } from "@/lib/qa.functions";
import type { Doc } from "@/lib/pdf";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Omnilegent — Ask your documents, see the evidence" },
      { name: "description", content: "Upload PDFs, scans and images. Ask questions answered from text, tables and charts — every claim cited by document, page and section." },
      { property: "og:title", content: "Omnilegent — Ask your documents, see the evidence" },
      { property: "og:description", content: "Multimodal document Q&A with page-level citations across text, tables, charts and scans." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

type Modality = "text" | "table" | "chart" | "image" | "scanned";
type Citation = { ref: number; document: string; page: number; section: string; modality: Modality; evidence: string };
type Turn = {
  id: string;
  question: string;
  status: "loading" | "done" | "error";
  answer?: string;
  confidence?: "high" | "medium" | "low";
  citations?: Citation[];
  error?: string;
  pagesRead?: number;
};

const MOD: Record<Modality, { label: string; icon: typeof FileText; cls: string }> = {
  text: { label: "Text", icon: FileText, cls: "text-mod-text border-mod-text/40 bg-mod-text/10" },
  table: { label: "Table", icon: Table2, cls: "text-mod-table border-mod-table/40 bg-mod-table/10" },
  chart: { label: "Chart", icon: BarChart3, cls: "text-mod-chart border-mod-chart/40 bg-mod-chart/10" },
  image: { label: "Image", icon: ImageIcon, cls: "text-mod-image border-mod-image/40 bg-mod-image/10" },
  scanned: { label: "Scan", icon: ScanLine, cls: "text-mod-scanned border-mod-scanned/40 bg-mod-scanned/10" },
};

function Index() {
  const [theme, setTheme] = useState<"light" | "dark">("light");
  useEffect(() => {
    try {
      const saved = localStorage.getItem("omnilegent-theme");
      const initial = saved === "dark" || saved === "light" ? saved : "light";
      setTheme(initial);
      document.documentElement.classList.toggle("dark", initial === "dark");
    } catch { /* Keep the light default when browser storage is unavailable. */ }
  }, []);

  function changeTheme(next: "light" | "dark") {
    setTheme(next);
    document.documentElement.classList.toggle("dark", next === "dark");
    try { localStorage.setItem("omnilegent-theme", next); } catch { /* Theme still works without storage. */ }
  }

  const [docs, setDocs] = useState<Doc[]>([]);
  const [ingesting, setIngesting] = useState<{ name: string; done: number; total: number } | null>(null);
  const [turns, setTurns] = useState<Turn[]>([]);
  const [q, setQ] = useState("");
  const [viewer, setViewer] = useState<{ doc: Doc; page: number; cite?: Citation | undefined } | null>(null);
  const [dragging, setDragging] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const ask = useServerFn(askDocuments);

  const addFiles = useCallback(async (files: FileList | File[]) => {
    const { ingestFile } = await import("@/lib/pdf");
    for (const f of Array.from(files)) {
      if (!(f.type === "application/pdf" || f.type.startsWith("image/"))) continue;
      setIngesting({ name: f.name, done: 0, total: 1 });
      try {
        const d = await ingestFile(f, (done, total) => setIngesting({ name: f.name, done, total }));
        setDocs((prev) => [...prev, d]);
      } catch (e) {
        console.error(e);
      }
    }
    setIngesting(null);
  }, []);

  const busy = turns.some((t) => t.status === "loading");

  async function submit(question: string) {
    if (!question.trim() || !docs.length || busy) return;
    const { selectPages } = await import("@/lib/pdf");
    const picked = selectPages(docs, question);
    const id = crypto.randomUUID();
    setTurns((t) => [...t, { id, question, status: "loading", pagesRead: picked.length }]);
    setQ("");
    const res = await ask({
      data: {
        question,
        pages: picked.map(({ doc, p }) => ({ document: doc.name, page: p.page, text: p.text, image: p.image })),
      },
    }).catch((e: Error) => ({ ok: false as const, error: e.message }));
    setTurns((t) =>
      t.map((x) =>
        x.id !== id ? x : res.ok
          ? { ...x, status: "done", answer: res.answer.answer, confidence: res.answer.confidence, citations: res.answer.citations as Citation[] }
          : { ...x, status: "error", error: res.error },
      ),
    );
  }

  function openCite(c: Citation) {
    const doc = docs.find((d) => d.name === c.document) ?? docs.find((d) => d.name.includes(c.document) || c.document.includes(d.name));
    if (doc) setViewer({ doc, page: c.page, cite: c });
  }

  return (
    <div
      className="min-h-screen"
      onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
      onDragLeave={(e) => { if (e.currentTarget === e.target) setDragging(false); }}
      onDrop={(e) => { e.preventDefault(); setDragging(false); addFiles(e.dataTransfer.files); }}
    >
      <header className="mx-auto flex max-w-7xl flex-wrap items-end justify-between gap-4 px-6 pb-6 pt-10">
        <div className="min-w-0">
          <p className="eyebrow">Evidence-grounded reading room</p>
          <h1 className="mt-1 text-4xl font-semibold text-ink sm:text-5xl">
            Omnilegent
          </h1>
        </div>
        <div className="flex flex-col items-end gap-3">
          <div role="group" aria-label="Color theme" className="flex gap-1 rounded-md border bg-paper p-1">
            <Button size="sm" variant={theme === "light" ? "secondary" : "ghost"} aria-pressed={theme === "light"} onClick={() => changeTheme("light")}>
              <Sun className="h-4 w-4" /> Light
            </Button>
            <Button size="sm" variant={theme === "dark" ? "secondary" : "ghost"} aria-pressed={theme === "dark"} onClick={() => changeTheme("dark")}>
              <Moon className="h-4 w-4" /> Dark
            </Button>
          </div>
          <p className="hidden max-w-sm text-right text-sm text-muted-foreground md:block">
            Answers drawn from text, tables, charts and scans — each claim pinned to its document, page and section.
          </p>
        </div>
      </header>

      <main className="mx-auto grid max-w-7xl gap-6 px-6 pb-16 lg:grid-cols-[320px_1fr]">
        {/* Library */}
        <aside className="space-y-4 lg:sticky lg:top-6 lg:self-start">
          <button
            onClick={() => fileRef.current?.click()}
            className={`sheet group flex w-full flex-col items-center gap-2 border-dashed px-4 py-8 text-center transition ${dragging ? "border-primary bg-accent" : "hover:border-primary"}`}
          >
            <Upload className="h-6 w-6 text-primary transition group-hover:-translate-y-0.5" />
            <span className="font-serif text-lg text-ink">Add documents</span>
            <span className="text-xs text-muted-foreground">PDFs, scans, photos of charts — drop or browse</span>
          </button>
          <input ref={fileRef} type="file" multiple accept="application/pdf,image/*" className="hidden" onChange={(e) => e.target.files && addFiles(e.target.files)} />

          {ingesting && (
            <div className="sheet relative overflow-hidden p-4">
              <div className="pointer-events-none absolute inset-x-0 top-0 h-6 animate-scan bg-gradient-to-b from-transparent via-primary/20 to-transparent" />
              <p className="eyebrow">Reading pages</p>
              <p className="mt-1 truncate text-sm">{ingesting.name}</p>
              <div className="mt-3 h-1 overflow-hidden rounded bg-muted">
                <div className="h-full bg-primary transition-all" style={{ width: `${(ingesting.done / ingesting.total) * 100}%` }} />
              </div>
              <p className="mt-1 font-mono text-xs text-muted-foreground">{ingesting.done} / {ingesting.total}</p>
            </div>
          )}

          <div className="sheet divide-y">
            <div className="flex items-center justify-between px-4 py-3">
              <p className="eyebrow">Library</p>
              <span className="font-mono text-xs text-muted-foreground">{docs.reduce((n, d) => n + d.pages.length, 0)} pages</span>
            </div>
            {docs.length === 0 && <p className="px-4 py-6 text-sm text-muted-foreground">No documents yet.</p>}
            {docs.map((d) => (
              <div key={d.id} className="px-4 py-3">
                <div className="flex items-start justify-between gap-2">
                  <p className="truncate text-sm font-medium text-ink" title={d.name}>{d.name}</p>
                  <button aria-label={`Remove ${d.name}`} onClick={() => setDocs((p) => p.filter((x) => x.id !== d.id))} className="text-muted-foreground hover:text-destructive">
                    <X className="h-4 w-4" />
                  </button>
                </div>
                <p className="font-mono text-[11px] text-muted-foreground">
                  {d.pages.length} pp · {d.pages.filter((p) => p.text.trim().length < 40).length} visual/scanned
                </p>
                <div className="mt-2 flex gap-1.5 overflow-x-auto pb-1">
                  {d.pages.slice(0, 30).map((p) => (
                    <button key={p.page} onClick={() => setViewer({ doc: d, page: p.page })} className="shrink-0 overflow-hidden rounded-sm border transition hover:-translate-y-0.5 hover:border-primary">
                      <img src={p.thumb} alt={`Page ${p.page}`} className="h-14 w-auto" />
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </aside>

        {/* Conversation */}
        <section className="flex min-h-[70vh] flex-col">
          <div className="flex-1 space-y-6">
            {turns.length === 0 && <EmptyState hasDocs={docs.length > 0} onPick={(s) => submit(s)} />}
            {turns.map((t) => (
              <TurnCard key={t.id} turn={t} onCite={openCite} docs={docs} />
            ))}
          </div>

          <form
            onSubmit={(e) => { e.preventDefault(); submit(q); }}
            className="sheet sticky bottom-4 mt-8 flex items-end gap-3 p-3 shadow-lift"
          >
            <textarea
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submit(q); } }}
              rows={2}
              placeholder={docs.length ? "Ask anything — e.g. Which region grew fastest, and does the chart agree with the table?" : "Add a document to begin"}
              disabled={!docs.length}
              className="flex-1 resize-none bg-transparent px-2 py-1 font-serif text-lg text-ink outline-none placeholder:text-muted-foreground/70"
            />
            <button
              type="submit"
              disabled={!q.trim() || !docs.length || busy}
              aria-label="Ask"
              className="flex h-11 w-11 items-center justify-center rounded-full bg-primary text-primary-foreground transition hover:scale-105 disabled:opacity-40"
            >
              {busy ? <Loader2 className="h-5 w-5 animate-spin" /> : <ArrowUp className="h-5 w-5" />}
            </button>
          </form>
        </section>
      </main>

      <Dialog open={!!viewer} onOpenChange={(o) => !o && setViewer(null)}>
        <DialogContent className="max-h-[92vh] max-w-4xl overflow-y-auto bg-paper">
          {viewer && <PageViewer viewer={viewer} setPage={(page) => setViewer({ ...viewer, page, cite: page === viewer.cite?.page ? viewer.cite : undefined })} />}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function EmptyState({ hasDocs, onPick }: { hasDocs: boolean; onPick: (s: string) => void }) {
  const samples = [
    "Summarise the key findings and cite where each comes from.",
    "What does the main chart show, and do the numbers match the tables?",
    "List every figure or table and what it measures.",
  ];
  return (
    <div className="sheet animate-rise p-10">
      <BookOpen className="h-8 w-8 text-primary" />
      <h2 className="mt-4 max-w-xl text-3xl leading-tight text-ink">
        Ask a question. Get an answer you can <em className="text-primary">verify</em>.
      </h2>
      <p className="mt-3 max-w-xl text-muted-foreground">
        Every page is read as an image as well as text, so charts, tables and scanned pages are actually looked at — not guessed from their captions.
      </p>
      <div className="mt-6 flex flex-wrap gap-2">
        {Object.entries(MOD).map(([k, m]) => (
          <span key={k} className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs ${m.cls}`}>
            <m.icon className="h-3.5 w-3.5" /> {m.label}
          </span>
        ))}
      </div>
      {hasDocs && (
        <div className="mt-8 grid gap-2">
          {samples.map((s) => (
            <button key={s} onClick={() => onPick(s)} className="rounded-md border bg-background/60 px-4 py-3 text-left text-sm transition hover:border-primary hover:bg-accent">
              {s}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function TurnCard({ turn, onCite, docs }: { turn: Turn; onCite: (c: Citation) => void; docs: Doc[] }) {
  const byRef = new Map((turn.citations ?? []).map((c) => [c.ref, c]));
  return (
    <article className="animate-rise space-y-3">
      <p className="font-serif text-2xl leading-snug text-ink">{turn.question}</p>
      <div className="sheet p-6">
        {turn.status === "loading" && (
          <div className="flex items-center gap-3 text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin text-primary" />
            <span className="text-sm">Examining {turn.pagesRead} pages — reading text, tables and charts visually…</span>
          </div>
        )}
        {turn.status === "error" && <p className="text-sm text-destructive">{turn.error}</p>}
        {turn.status === "done" && (
          <>
            <div className="mb-4 flex items-center gap-2">
              <span className="eyebrow">Answer</span>
              <span className={`rounded-full px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider ${turn.confidence === "high" ? "bg-mod-table/15 text-mod-table" : turn.confidence === "medium" ? "bg-mod-scanned/15 text-mod-scanned" : "bg-destructive/10 text-destructive"}`}>
                {turn.confidence} confidence
              </span>
            </div>
            <div className="space-y-3 leading-relaxed text-foreground">
              <Markdown text={turn.answer ?? ""} onRef={(n) => { const c = byRef.get(n); if (c) onCite(c); }} />
            </div>
            {!!turn.citations?.length && (
              <div className="mt-6 border-t pt-4">
                <p className="eyebrow mb-3">Sources</p>
                <div className="grid gap-2 sm:grid-cols-2">
                  {turn.citations.map((c) => {
                    const m = MOD[c.modality] ?? MOD.text;
                    const doc = docs.find((d) => d.name === c.document);
                    const thumb = doc?.pages.find((p) => p.page === c.page)?.thumb;
                    return (
                      <button key={c.ref} onClick={() => onCite(c)} className="group flex gap-3 rounded-md border bg-background/50 p-3 text-left transition hover:border-primary hover:shadow-sheet">
                        {thumb && <img src={thumb} alt="" className="h-16 w-12 shrink-0 rounded-sm border object-cover object-top" />}
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs font-medium text-primary">[{c.ref}]</span>
                            <span className={`inline-flex items-center gap-1 rounded-full border px-1.5 py-px text-[10px] ${m.cls}`}>
                              <m.icon className="h-3 w-3" /> {m.label}
                            </span>
                          </div>
                          <p className="mt-1 truncate text-sm font-medium text-ink">{c.document}</p>
                          <p className="truncate font-mono text-[11px] text-muted-foreground">p. {c.page} · {c.section}</p>
                          <p className="mt-1 line-clamp-2 text-xs italic text-muted-foreground">“{c.evidence}”</p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </article>
  );
}

function inline(text: string, onRef: (n: number) => void): ReactNode[] {
  const parts = text.split(/(\[\d+(?:,\s*\d+)*\]|\*\*[^*]+\*\*)/g);
  return parts.map((p, i) => {
    const ref = p.match(/^\[(\d+(?:,\s*\d+)*)\]$/);
    if (ref) {
      return (ref[1] ?? "").split(/,\s*/).map((n) => (
        <button key={`${i}-${n}`} onClick={() => onRef(Number(n))} className="mx-0.5 inline-flex h-5 min-w-5 -translate-y-0.5 items-center justify-center rounded bg-primary/10 px-1 font-mono text-[11px] font-medium text-primary transition hover:bg-primary hover:text-primary-foreground">
          {n}
        </button>
      ));
    }
    if (p.startsWith("**") && p.endsWith("**")) return <strong key={i} className="font-semibold text-ink">{p.slice(2, -2)}</strong>;
    return <span key={i}>{p}</span>;
  });
}

function Markdown({ text, onRef }: { text: string; onRef: (n: number) => void }) {
  const blocks = text.split(/\n{2,}/);
  return (
    <>
      {blocks.map((b, i) => {
        const lines = b.split("\n").filter(Boolean);
        if (lines.every((l) => /^\s*([-*]|\d+\.)\s/.test(l))) {
          return (
            <ul key={i} className="space-y-1.5 pl-1">
              {lines.map((l, j) => (
                <li key={j} className="flex gap-2">
                  <span className="mt-2.5 h-1 w-1 shrink-0 rounded-full bg-primary" />
                  <span>{inline(l.replace(/^\s*([-*]|\d+\.)\s/, ""), onRef)}</span>
                </li>
              ))}
            </ul>
          );
        }
        const h = b.match(/^#{1,4}\s+(.*)/);
        if (h) return <h3 key={i} className="text-lg text-ink">{inline(h[1] ?? "", onRef)}</h3>;
        return <p key={i}>{inline(b, onRef)}</p>;
      })}
    </>
  );
}

function PageViewer({ viewer, setPage }: { viewer: { doc: Doc; page: number; cite?: Citation | undefined }; setPage: (p: number) => void }) {
  const { doc, page, cite } = viewer;
  const p = doc.pages.find((x) => x.page === page) ?? doc.pages[0]!;
  const m = cite ? MOD[cite.modality] ?? MOD.text : null;
  return (
    <div className="space-y-4">
      <div>
        <p className="eyebrow">{doc.name}</p>
        <DialogTitle className="font-serif text-2xl text-ink">Page {p.page} of {doc.pages.length}</DialogTitle>
      </div>
      {cite && m && (
        <div className="rounded-md border-l-4 border-primary bg-accent/50 p-3 text-sm">
          <div className="flex flex-wrap items-center gap-2">
            <span className={`inline-flex items-center gap-1 rounded-full border px-1.5 py-px text-[10px] ${m.cls}`}><m.icon className="h-3 w-3" /> {m.label}</span>
            <span className="font-medium text-ink">{cite.section}</span>
          </div>
          <p className="mt-1 italic text-muted-foreground">“{cite.evidence}”</p>
        </div>
      )}
      <img src={p.image} alt={`${doc.name} page ${p.page}`} className="w-full rounded border shadow-sheet" />
      <div className="flex justify-between">
        <button disabled={p.page <= 1} onClick={() => setPage(p.page - 1)} className="rounded-md border px-3 py-1.5 text-sm disabled:opacity-40 hover:border-primary">← Previous</button>
        <button disabled={p.page >= doc.pages.length} onClick={() => setPage(p.page + 1)} className="rounded-md border px-3 py-1.5 text-sm disabled:opacity-40 hover:border-primary">Next →</button>
      </div>
    </div>
  );
}
